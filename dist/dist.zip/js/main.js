"use strict";

/* jQuery */
$(function () {});